from . import canvas
from . import combobox
from . import label
from . import lineedit
from . import plaintextedit
from . import pushbutton
from . import toolbutton
name = "widgets"
