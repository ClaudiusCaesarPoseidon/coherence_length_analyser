# pylint: disable=line-too-long
# pylint: disable=C0103
# pylint: disable=C0111
# pylint: disable=C0411
# pylint: disable=C0412
# pylint: disable=C0413
# pylint: disable=R0902
# pylint: disable=R0912
# pylint: disable=R0914
# pylint: disable=R0915
# pylint: disable=E1101

# loads the main class of the modules_master submodule
from .modules_master.master import Master
