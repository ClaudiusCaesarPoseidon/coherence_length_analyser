# pylint: disable=line-too-long
# pylint: disable=C0103
# pylint: disable=C0111
# pylint: disable=C0330
# pylint: disable=C0413
# pylint: disable=C0411
# pylint: disable=R0903
# pylint: disable=R0201
# pylint: disable=R1705
# pylint: disable=E1101

# loads the content of the modules_eigen_widgets submodule
from .modules_eigen_widgets.dialog import Dialog
from .modules_eigen_widgets.widget import Widget
from .modules_eigen_widgets.widgetb import Widgetb
from .modules_eigen_widgets.stream import Stream
from .modules_eigen_widgets.command_line_arguments import Command_Line_Arguments
from .modules_eigen_widgets.screen_size_dialog import screen_size_dialog
