# pylint: disable=C0301
# pylint: disable=R0903
# pylint: disable=R0904
# pylint: disable=R0902
# pylint: disable=R0912
# pylint: disable=R0915
# pylint: disable=R1702
# pylint: disable=W0612
# pylint: disable=C0111
# pylint: disable=C0410
# pylint: disable=C0413
# pylint: disable=C0412
# pylint: disable=C0411
# pylint: disable=C0103
# pylint: disable=E1101

# loads the main class of the modules_camera submodule
from .modules_camera.camera import Camera
