from . import analyser
from . import camera
from . import eigen_widgets
from . import angle
from . import turn
from . import master
name = "modules"
