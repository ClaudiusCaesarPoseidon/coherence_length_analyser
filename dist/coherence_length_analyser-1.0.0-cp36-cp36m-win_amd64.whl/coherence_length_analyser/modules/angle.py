# loads the main class of the modules_angle submodule
from .modules_angle.angle import Angle
